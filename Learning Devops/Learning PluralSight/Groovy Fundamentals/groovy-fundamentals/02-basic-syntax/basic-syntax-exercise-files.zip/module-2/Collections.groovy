def beatles = ["John","Paul","George","Ringo"]
for (beatle in beatles) {
	def greeting = "Hello, "
	println "$greeting" + "$beatle"
}