def cat = "meow"
def one = 1

println cat
println cat.getClass()
println cat.toUpperCase()

println one
println one.getClass()

one = "one"
println one.getClass()
println one.toUpperCase()
