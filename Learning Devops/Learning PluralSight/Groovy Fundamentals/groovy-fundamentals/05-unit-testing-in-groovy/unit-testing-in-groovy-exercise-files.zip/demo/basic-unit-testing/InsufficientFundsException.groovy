class InsufficientFundsException extends Exception {
	
}