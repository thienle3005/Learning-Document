class InterestRateService {
	def double getInterestRate() {
		// This is where we would call out to a
		// web service to retrieve today's interest rate

		// Instead of returning 0.0, we would return the current rate
		return 0.0
	}
}