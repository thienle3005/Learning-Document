// Visit https://darksky.net/dev/ to sign up for an API key then insert it below
apiKey='INSERT_DARKSKY_API_KEY_HERE'

database.user = 'root'
database.password = 'p@ssw0rd'
