package com.mantiso;

public class User {
    private String _name;
    private String _email;

    public String getName(){
        return _name;
    }

    public void setName(String value){
        _name = value;
    }

    public String getEmail(){
        return _email;
    }

    public void setEmail(String value){
        _email = value;
    }

}
