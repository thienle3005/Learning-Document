package com.mantiso;

/**
 * Created by kevinj.
 */
public class CssClass {
    private String _name;

    public String getName(){
        return _name;
    }
    public void setName(String value){
        _name = value;
    }

}
